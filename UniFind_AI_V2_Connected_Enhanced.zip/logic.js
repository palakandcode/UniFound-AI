const API=window.UNIFIND_API || (location.port==="5000" ? "/api" : `${location.protocol}//${location.hostname}:5000/api`);
const API_ORIGIN=API.replace(/\/api\/?$/,"");
const TOKEN_KEY="unifind_token";
let token=localStorage.getItem(TOKEN_KEY);
let user=null, items=[], notes=[], claims=[], conversations=[], activeConversation=null, homeFilter="all", lastFocus=null, signupFile=null, signupOcrText="";

const esc=s=>String(s??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
const cat=s=>({electronics:"Electronics",accessories:"Accessories","id-cards":"ID Cards",books:"Books",other:"Other"}[String(s||"").toLowerCase()]||"Other");
const date=s=>s?new Date(String(s).slice(0,10)+"T00:00:00").toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"}):"Date not specified";
const statusText=s=>String(s||"").toLowerCase();
const imageUrl=p=>{if(!p)return ""; if(/^https?:\/\//.test(p))return p; let x=String(p).replaceAll("\\","/"); x=x.replace(/^.*?uploads\//,"/uploads/"); return API_ORIGIN+(x.startsWith("/")?x:"/"+x)};
const api=async(path,opts={})=>{const h=new Headers(opts.headers||{}); if(token)h.set("Authorization","Bearer "+token); if(opts.body && !(opts.body instanceof FormData))h.set("Content-Type","application/json"); const r=await fetch(API+path,{...opts,headers:h}); let d={}; try{d=await r.json()}catch{} if(r.status===401){logout(false); throw new Error("Your session expired. Please sign in again.")} if(!r.ok)throw new Error(d.message||`Request failed (${r.status})`); return d};

function modal(id,on=true){let e=typeof id==="string"?document.getElementById(id):id;if(!e)return;if(on){lastFocus=document.activeElement;e.classList.add("open");e.setAttribute("aria-hidden","false");document.body.style.overflow="hidden";e.querySelector("button,input,textarea,select")?.focus()}else{e.classList.remove("open");e.setAttribute("aria-hidden","true");if(!document.querySelector(".modal-backdrop.open")){document.body.style.overflow="";lastFocus?.focus()}}}
function toast(m){let e=document.getElementById("toast");if(!e)return;e.textContent=m;e.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove("show"),3000)}

function mapItem(i){
 return {id:i.id,type:String(i.type||"").toLowerCase(),title:i.title,category:String(i.category||"").toLowerCase(),
 description:i.description,details:i.identifying_characteristics||"",date:i.event_date,time:i.approximate_time||"",
 location:i.location,storageLocation:i.storage_location||"",image:imageUrl(i.image_path),ownerId:i.owner_id,
 ownerName:i.owner_name||"",ownerAvatar:imageUrl(i.owner_avatar),status:statusText(i.status),createdAt:i.created_at,raw:i};
}
async function loadItems(){
 const d=await api("/items?status=all&limit=100"); items=(d.items||[]).map(mapItem);
}
async function loadNotes(){
 try{const d=await api("/notifications");notes=(d.notifications||[]).map(n=>({id:n.id,title:n.title,body:n.message,time:n.created_at,unread:!n.read_at,type:n.type,itemId:n.item_id}));}
 catch{notes=[]}
}
function media(i,cls="item-image"){return i.image?`<div class="${cls}"><img src="${esc(i.image)}" alt="${esc(i.title)}"><span class="status-badge ${i.type}">${i.status==="returned"?"Returned":i.status==="claimed"?"Claimed":i.type==="lost"?"Lost":"Found"}</span></div>`:`<div class="${cls}"><div class="placeholder-image">◈</div><span class="status-badge ${i.type}">${i.status==="returned"?"Returned":i.status==="claimed"?"Claimed":i.type==="lost"?"Lost":"Found"}</span></div>`}
function card(i){
 let own=i.ownerId===user.id, claim=i.type==="found"&&!own&&i.status==="active";
 return `<article class="item-card">${media(i)}<div class="item-info"><h3>${esc(i.title)}</h3><p class="item-description">${esc(i.description)}</p><div class="item-details"><span>📍 ${esc(i.location)}</span><span>📅 ${date(i.date)}${i.time?" · "+esc(i.time):""}</span>${i.type==="found"&&i.storageLocation?`<span>🔐 Stored at ${esc(i.storageLocation)}</span>`:""}</div><span class="category">${esc(cat(i.category))}</span><div class="card-footer"><button class="card-link" data-view-item="${esc(i.id)}">View details →</button>${claim?`<button class="card-link" data-claim-item="${esc(i.id)}">This might be mine</button>`:own?`<span style="font-size:11px;color:#667085;font-weight:700;">Your report</span>`:""}</div></div></article>`
}
function grid(id,list,title,text){let e=document.getElementById(id);if(!e)return;e.innerHTML=list.length?list.map(card).join(""):`<div class="empty-state"><div class="empty-icon">⌕</div><h3>${esc(title)}</h3><p>${esc(text)}</p></div>`}
function active(){return items.filter(i=>i.status==="active")}

async function loadClaims(){try{const d=await api("/claims");claims=d.claims||[]}catch{claims=[]}}
function claimStatus(c){return String(c.status||"").toLowerCase()}
function renderClaims(){
 const mine=document.getElementById("myClaimsList"), incoming=document.getElementById("incomingClaimsList");
 const mineRows=claims.filter(c=>c.claimant_id===user.id);
 const incomingRows=claims.filter(c=>c.owner_id===user.id);
 const claimCard=(c,ownerView)=>`<article class="claim-card"><div class="claim-card-main"><h3>${esc(c.title)}</h3><p>${ownerView?`Claim from <strong>${esc(c.claimant_name||"Student")}</strong> · ${esc(c.claimant_member_id||"ID unavailable")} · <strong>${c.claimant_verification_status==='VERIFIED'?'Verified ID':'ID pending'}</strong>`:`Claim submitted · ${esc(c.item_status||"")}`}</p><p>${esc(c.message||"")}</p><span class="claim-status ${claimStatus(c)}">${esc(c.status)}</span></div><div class="claim-actions">${ownerView&&c.status==="PENDING"?`<button class="btn-mini approve" data-approve-claim="${esc(c.id)}">Approve</button><button class="btn-mini reject" data-reject-claim="${esc(c.id)}">Reject</button>`:""}${!ownerView&&c.status==="APPROVED"?`<button class="btn-mini" data-open-chat-user="${esc(c.item_owner_id||"")}" data-chat-item="${esc(c.item_id||"")}">Message finder</button>${c.item_status==="CLAIMED"?`<button class="btn-mini receive" data-received-claim="${esc(c.id)}">I received it</button>`:""}`:""}</div></article>`;
 if(mine)mine.innerHTML=mineRows.length?mineRows.map(c=>claimCard(c,false)).join(""):`<div class="empty-state"><h3>No claims yet</h3><p>When you find a possible match, submit an ownership explanation.</p></div>`;
 if(incoming)incoming.innerHTML=incomingRows.length?incomingRows.map(c=>claimCard(c,true)).join(""):`<div class="empty-state"><h3>No incoming claims</h3><p>Claims for your found items will appear here.</p></div>`;
}
async function reviewClaim(id,status){try{await api(`/claims/${id}`,{method:"PATCH",body:JSON.stringify({status})});toast(status==="APPROVED"?"Claim approved. The claimant can now message you.":"Claim rejected.");await refresh()}catch(e){toast(e.message)}}
async function markReceivedClaim(id){try{await api(`/claims/${id}/received`,{method:"POST"});toast("Receipt confirmed. Item marked returned.");await refresh()}catch(e){toast(e.message)}}
async function loadConversations(){try{const d=await api("/conversations");conversations=d.conversations||[]}catch{conversations=[]}renderConversations()}
function conversationOther(c){return (c.participants||[]).find(p=>p.id!==user.id)||{}}
function renderConversations(){
 const e=document.getElementById("conversationList"),count=document.getElementById("messageCount"); if(!e)return;
 if(count)count.textContent=conversations.length;
 e.innerHTML=conversations.length?conversations.map(c=>{const o=conversationOther(c);return `<button class="conversation-item ${activeConversation===c.id?"active":""}" data-conversation="${esc(c.id)}"><strong>${esc(o.name||"Student")}</strong><span>${esc(c.item_title||"UniFind handover")}</span><span>${esc(c.last_message||"Conversation ready")}</span></button>`}).join(""):`<div class="empty-state"><h3>No messages yet</h3><p>Approved claims create a private conversation.</p></div>`;
}
async function openConversation(id){
 activeConversation=id;renderConversations();
 const c=conversations.find(x=>x.id===id),head=document.getElementById("chatHeader"),box=document.getElementById("chatMessages"),input=document.getElementById("messageInput"),send=document.querySelector("#messageForm button");
 if(!c)return;
 const o=conversationOther(c); if(head)head.textContent=`${o.name||"Student"} · ${c.item_title||"UniFind handover"}`;
 try{const d=await api(`/conversations/${id}/messages`);if(box)box.innerHTML=(d.messages||[]).map(m=>`<div class="bubble ${m.sender_id===user.id?"mine":""}">${esc(m.content)}<small>${esc(new Date(m.created_at).toLocaleString("en-IN",{dateStyle:"medium",timeStyle:"short"}))}</small></div>`).join("")||'<div class="empty-state"><h3>Start the handover conversation</h3></div>';box.scrollTop=box.scrollHeight;if(input){input.disabled=false;input.focus()}if(send)send.disabled=false}catch(e){toast(e.message)}
}
async function sendMessage(e){e.preventDefault();if(!activeConversation)return;const input=document.getElementById("messageInput"),content=input.value.trim();if(!content)return;try{await api(`/conversations/${activeConversation}/messages`,{method:"POST",body:JSON.stringify({content})});input.value="";await openConversation(activeConversation);await loadConversations()}catch(e){toast(e.message)}}
async function messageWithUser(otherUserId,itemId){if(!otherUserId)return toast("The other participant is not available.");try{const d=await api("/conversations",{method:"POST",body:JSON.stringify({otherUserId,itemId})});await loadConversations();navigate("messages");await openConversation(d.conversationId)}catch(e){toast(e.message)}}

function renderHome(){let q=(document.getElementById("homeSearch")?.value||"").trim().toLowerCase();let f=i=>{let h=[i.title,i.description,i.location,cat(i.category)].join(" ").toLowerCase();return(!q||h.includes(q))&&(homeFilter==="all"||homeFilter===i.type||homeFilter===i.category)};grid("homeLostGrid",active().filter(i=>i.type==="lost").filter(f).slice(0,6),"No active lost reports","No lost items match this search or filter.");grid("homeFoundGrid",active().filter(i=>i.type==="found").filter(f).slice(0,6),"No active found reports","No found items match this search or filter.")}
function renderMine(){let m=items.filter(i=>i.ownerId===user.id);grid("myLostGrid",m.filter(i=>i.type==="lost"),"You haven't reported a lost item","Use “I Lost Something” to create a report.");grid("myFoundGrid",m.filter(i=>i.type==="found"),"You haven't reported a found item","Use “I Found Something” to create a report.");["profileLostCount","profileFoundCount","profileReturnedCount"].forEach(id=>{let e=document.getElementById(id);if(e)e.textContent=id==="profileLostCount"?m.filter(i=>i.type==="lost").length:id==="profileFoundCount"?m.filter(i=>i.type==="found").length:m.filter(i=>i.status==="returned").length})}
function search(){
 let q=document.getElementById("searchPageInput").value.trim().toLowerCase(),st=document.getElementById("searchStatus").value,ca=document.getElementById("searchCategory").value,lo=document.getElementById("searchLocation").value,so=document.getElementById("searchSort").value;
 let r=active().filter(i=>{let h=[i.title,i.description,i.details,i.location,cat(i.category)].join(" ").toLowerCase();return(!q||h.includes(q))&&(st==="all"||i.type===st)&&(ca==="all"||i.category===ca)&&(lo==="all"||i.location===lo)}).sort((a,b)=>so==="newest"?new Date(b.createdAt)-new Date(a.createdAt):new Date(a.createdAt)-new Date(b.createdAt));
 document.getElementById("resultCount").textContent=`${r.length} result${r.length===1?"":"s"}`;document.getElementById("searchHint").textContent=q?`Results for “${q}”`:"Showing active reports";grid("searchResults",r,"No matching items","Try another keyword or remove a filter.")
}
async function matches(){
 let lost=items.filter(i=>i.ownerId===user.id&&i.type==="lost"&&i.status==="active"),out=[];
 for(const l of lost){try{let d=await api(`/items/${l.id}/matches`);(d.matches||[]).forEach(x=>out.push({l,f:mapItem(x.item),s:x.score,reasons:x.reasons||[]}))}catch{}}
 out.sort((a,b)=>b.s-a.s);let e=document.getElementById("matchesList");if(!e)return;e.innerHTML=out.length?out.map(x=>`<article class="match-card"><div class="match-thumb">${x.f.image?`<img src="${esc(x.f.image)}" alt="${esc(x.f.title)}">`:`<div class="placeholder-image">◈</div>`}</div><div class="match-content"><h3>${esc(x.f.title)}</h3><p>Potential match for <strong>${esc(x.l.title)}</strong>. ${esc(x.reasons.join(", ")||"Similar item details contributed to this suggestion.")}.</p><button class="card-link" data-view-item="${esc(x.f.id)}">Review found item →</button></div><div class="match-score">${x.s}%<small>POTENTIAL MATCH</small></div></article>`).join(""):`<div class="empty-state"><div class="empty-icon">✦</div><h3>No strong potential matches yet</h3><p>Keep your lost report active. New found reports can create a match later.</p></div>`
}
function renderNotes(){let e=document.getElementById("notificationsList");if(!e)return;e.innerHTML=notes.length?notes.map(n=>`<article class="notification ${n.unread?"unread":""}"><div class="notification-icon">${String(n.type||"").includes("CLAIM")?"✓":"✦"}</div><div><h3>${esc(n.title)}</h3><p>${esc(n.body)}</p><time>${esc(new Date(n.time).toLocaleString("en-IN",{dateStyle:"medium",timeStyle:"short"}))}</time></div></article>`).join(""):`<div class="empty-state"><div class="empty-icon">♢</div><h3>You're all caught up</h3><p>New updates will appear here.</p></div>`;let b=document.getElementById("notificationCount"),u=notes.filter(n=>n.unread).length;if(b){b.textContent=u;b.style.display=u?"grid":"none"}}
async function markNotificationsRead(){for(const n of notes.filter(n=>n.unread)){try{await api(`/notifications/${n.id}/read`,{method:"PATCH"})}catch{}}notes.forEach(n=>n.unread=false);renderNotes()}
function report(type){
 document.getElementById("reportForm").reset();document.getElementById("uploadPreview").innerHTML="＋";document.getElementById("uploadText").textContent="Add a photo";document.getElementById("formError").textContent="";document.getElementById("reportType").value=type;document.getElementById("reportIcon").textContent=type==="lost"?"↗":"↙";document.getElementById("reportEyebrow").textContent=type==="lost"?"LOST REPORT":"FOUND REPORT";document.getElementById("reportTitle").textContent=type==="lost"?"Report a Lost Item":"Report a Found Item";document.getElementById("reportSubtitle").textContent=type==="lost"?"Give enough information for other students to recognize the item.":"Help the owner recognize and safely recover what you found.";document.getElementById("storageLabel").classList.toggle("hidden-field",type==="lost");document.getElementById("storageLocation").required=type!=="lost";document.getElementById("submitReportBtn").textContent=type==="lost"?"Publish Lost Report":"Publish Found Report";document.getElementById("submitReportBtn").className=`btn ${type==="lost"?"btn-danger":"btn-success"}`;document.getElementById("eventDate").valueAsDate=new Date();modal("reportModal")
}
function detail(id){
 let i=items.find(x=>x.id===id);if(!i)return;let own=i.ownerId===user.id,claim=i.type==="found"&&!own&&i.status==="active";
 document.getElementById("itemDetailContent").innerHTML=`<div class="detail-hero"><div class="detail-photo">${i.image?`<img src="${esc(i.image)}" alt="${esc(i.title)}">`:`<div class="placeholder-image">◈</div>`}</div><div class="detail-main"><span class="status-badge ${i.type}" style="position:static;display:inline-block;">${i.status==="returned"?"Returned":i.status==="claimed"?"Claimed":i.type==="lost"?"Lost":"Found"}</span><h2>${esc(i.title)}</h2><p>${esc(i.description)}</p><div class="detail-meta"><span>📁 ${esc(cat(i.category))}</span><span>📍 ${esc(i.location)}</span><span>📅 ${date(i.date)}${i.time?" · "+esc(i.time):""}</span>${i.type==="found"&&i.storageLocation?`<span>🔐 Current location: ${esc(i.storageLocation)}</span>`:""}</div><div class="detail-note"><strong>DISTINGUISHING DETAILS</strong><p>${esc(i.details||"Private identifying details are protected.")}</p></div>${claim?`<button class="btn btn-success" data-claim-item="${esc(i.id)}">This might be mine</button>`:own&&i.status==="active"?`<button class="btn btn-outline" data-mark-returned="${esc(i.id)}">Mark as returned</button>`:""}</div></div>`;modal("itemModal")
}
function claimOpen(id){let i=items.find(x=>x.id===id);if(!i||i.type!=="found"||i.ownerId===user.id||i.status!=="active"){toast("This item cannot be claimed.");return}if(user?.verificationStatus!=="VERIFIED"){toast("Verify your Somaiya ID before claiming an item.");navigate("profile");return}document.getElementById("claimItemId").value=id;document.getElementById("claimReason").value="";document.getElementById("claimError").textContent="";document.getElementById("claimItemPreview").textContent=`${i.title} · ${i.location}`;modal("itemModal",false);modal("claimModal")}
async function submitClaim(e){e.preventDefault();let id=document.getElementById("claimItemId").value,r=document.getElementById("claimReason").value.trim();if(r.length<15){document.getElementById("claimError").textContent="Please provide at least 15 characters explaining why it is yours.";return}try{await api(`/items/${id}/claims`,{method:"POST",body:JSON.stringify({message:r})});modal("claimModal",false);toast("Claim submitted successfully.");await refresh();}catch(err){document.getElementById("claimError").textContent=err.message}}
async function returned(id){try{await api(`/items/${id}/return`,{method:"POST"});modal("itemModal",false);toast("Item marked returned.");await refresh()}catch(err){toast(err.message)}}
function upload(e){let f=e.target.files[0];if(!f)return;if(!["image/jpeg","image/png","image/webp"].includes(f.type)||f.size>5*1024*1024){toast("Please choose a JPG, PNG or WEBP image under 5 MB.");e.target.value="";return}let r=new FileReader();r.onload=()=>{document.getElementById("uploadPreview").innerHTML=`<img src="${r.result}" alt="Selected item preview">`;document.getElementById("uploadText").textContent="Photo selected"};r.readAsDataURL(f)}
async function submitReport(e){
 e.preventDefault();let t=document.getElementById("reportType").value,form=document.getElementById("reportForm"),fd=new FormData();
 const vals={type:t,title:itemTitle.value.trim(),category:itemCategory.value,description:itemDescription.value.trim(),eventDate:eventDate.value,approximateTime:eventTime.value,location:itemLocation.value,color:document.getElementById("itemColor")?.value||"",brand:document.getElementById("itemBrand")?.value||"",identifyingCharacteristics:itemDetails.value.trim(),storageLocation:storageLocation.value.trim()};
 if(!vals.title||!vals.category||!vals.description||!vals.eventDate||!vals.location||(t==="found"&&!vals.storageLocation)){document.getElementById("formError").textContent="Please complete all required fields.";return}
 Object.entries(vals).forEach(([k,v])=>fd.append(k,v));let file=document.getElementById("itemImage").files[0];if(file)fd.append("image",file);
 try{await api("/items",{method:"POST",body:fd});modal("reportModal",false);toast(`${t==="lost"?"Lost":"Found"} report published successfully.`);await refresh();navigate(t==="lost"?"items-lost":"items-found")}catch(err){document.getElementById("formError").textContent=err.message}
}
async function loadProfile(){
 let d=await api("/profile"),u=d.user;user=u;
 const set=(id,v)=>{let e=document.getElementById(id);if(e)e.value=v??""}; 
 document.getElementById("profileName").textContent=u.name||"Student";document.getElementById("profileEmail").textContent=u.email||"";
 document.getElementById("profileVerification").textContent=(u.verificationStatus||"PENDING")==="VERIFIED"?"✓ Verified university account":"✓ Account verification: "+String(u.verificationStatus||"PENDING").toLowerCase();
 set("profileEditName",u.name);set("profileEditMemberId",u.memberId);set("profileEditPhone",u.phone);set("profileEditDepartment",u.department);set("profileEditCourse",u.course);set("profileEditYearBatch",u.yearBatch);
 document.getElementById("allowMessages") && (document.getElementById("allowMessages").checked=!!u.contactPreferences?.messages); document.getElementById("allowCalls") && (document.getElementById("allowCalls").checked=!!u.contactPreferences?.calls); document.getElementById("allowEmail") && (document.getElementById("allowEmail").checked=!!u.contactPreferences?.email);
 let av=document.getElementById("profileAvatar");if(av){if(u.avatar){av.innerHTML=`<img src="${esc(imageUrl(u.avatar))}" alt="Profile photo">`}else av.textContent=(u.name||"S").split(/\s+/).map(x=>x[0]).join("").slice(0,2).toUpperCase()}
 document.getElementById("idCardStatus").textContent=u.idCard?(u.idCardOcrText?"Uploaded — details extracted; verification status: "+String(u.verificationStatus||"PENDING").toLowerCase():"Uploaded — awaiting verification"):"Not uploaded";
}
async function saveContactPrefs(){try{await api("/profile",{method:"PATCH",body:JSON.stringify({allowMessages:document.getElementById("allowMessages").checked,allowCalls:document.getElementById("allowCalls").checked,allowEmail:document.getElementById("allowEmail").checked})});await loadProfile();toast("Contact preferences saved.")}catch(e){toast(e.message)}}
async function saveProfile(e){e.preventDefault();try{await api("/profile",{method:"PATCH",body:JSON.stringify({name:profileEditName.value.trim(),memberId:profileEditMemberId.value.trim(),phone:profileEditPhone.value.trim(),department:profileEditDepartment.value.trim(),course:profileEditCourse.value.trim(),yearBatch:profileEditYearBatch.value.trim()})});await loadProfile();toast("Profile saved.");}catch(err){profileError.textContent=err.message}}
async function uploadAvatar(e){let f=e.target.files[0];if(!f)return;let fd=new FormData();fd.append("avatar",f);try{await api("/profile/avatar",{method:"POST",body:fd});await loadProfile();toast("Profile photo updated.")}catch(err){toast(err.message)}}
async function uploadId(e){let f=e.target.files[0];if(!f)return;let fd=new FormData();fd.append("idCard",f);try{await api("/profile/id-card",{method:"POST",body:fd});await loadProfile();toast("ID card uploaded for verification.")}catch(err){toast(err.message)}}
async function refresh(){await Promise.all([loadItems(),loadNotes(),loadProfile(),loadClaims(),loadConversations()]);renderAll()}
function renderAll(){renderHome();renderMine();renderNotes();renderClaims();search();renderConversations()}
function navigate(p){let ok=["home","search","items-lost","items-found","matches","notifications","messages","profile","settings","contact"];if(!ok.includes(p))p="home";history.pushState({p},"","#"+p);showPage(p)}
function showPage(p){let ok=["home","search","items-lost","items-found","matches","notifications","messages","profile","settings","contact"];if(!ok.includes(p))p="home";document.querySelectorAll(".page").forEach(e=>e.classList.toggle("active-page",e.id===p));document.querySelectorAll(".nav-link").forEach(e=>e.classList.toggle("active",e.dataset.page===p));if(p==="search")search();if(p==="matches")matches();if(p==="notifications")markNotificationsRead();if(p==="messages")loadConversations();window.scrollTo({top:0,behavior:"smooth"})}
function logout(show=true){token=null;user=null;localStorage.removeItem(TOKEN_KEY);document.getElementById("authScreen")?.classList.remove("hidden");document.getElementById("authScreen")?.setAttribute("aria-hidden","false");if(show)toast("Signed out.")}
async function login(e){e.preventDefault();let err=document.getElementById("loginError");err.textContent="";try{let j=await api("/auth/login",{method:"POST",body:JSON.stringify({identifier:loginIdentifier.value.trim(),password:loginPassword.value})});token=j.token;localStorage.setItem(TOKEN_KEY,token);user=j.user;document.getElementById("authScreen").classList.add("hidden");await refresh();navigate(location.hash.slice(1)||"home");toast("Welcome back, "+user.name+"!")}catch(x){err.textContent=x.message}}

async function previewSignupId(e){
 const file=e.target.files[0]; if(!file)return; signupFile=file;
 document.getElementById("signupIdCardText").textContent=file.name;
 const status=document.getElementById("signupOcrStatus");status.textContent="Reading ID card…";
 if(window.Tesseract){
   try{
     const result=await Tesseract.recognize(file,"eng");
     signupOcrText=String(result.data?.text||"").trim();
     status.textContent=signupOcrText?"ID details extracted. We'll compare them after signup.":"Photo selected. OCR could not read enough text.";
   }catch{status.textContent="Photo selected. OCR will be retried after account creation."}
 }else status.textContent="Photo selected. OCR service unavailable in this browser.";
}
async function requestSignupOtp(){
 const email=document.getElementById("signupEmail").value.trim(),err=document.getElementById("signupError");
 err.textContent=""; if(!email){err.textContent="Enter your email first.";return}
 try{await api("/auth/request-signup-otp",{method:"POST",body:JSON.stringify({email})});toast("OTP sent to "+email)}catch(e){err.textContent=e.message}
}
async function signup(e){
 e.preventDefault();const err=document.getElementById("signupError");err.textContent="";
 const name=signupName.value.trim(),memberId=signupMemberId.value.trim(),email=signupEmail.value.trim(),password=signupPassword.value,password2=signupPassword2.value,otp=signupOtp.value.trim();
 if(password!==password2){err.textContent="Passwords do not match.";return} if(!signupFile){err.textContent="Upload your Somaiya ID card to continue.";return}
 try{
   const d=await api("/auth/register",{method:"POST",body:JSON.stringify({name,memberId,email,password,otp})});
   token=d.token;localStorage.setItem(TOKEN_KEY,token);user=d.user;
   const fd=new FormData();fd.append("idCard",signupFile);
   const verification=await api("/profile/id-card",{method:"POST",body:fd});
   user=verification.user;
   document.getElementById("authScreen").classList.add("hidden");
   await refresh();navigate("home");
   toast(verification.verificationMatched?"Account created and ID verified.":"Account created. ID verification is pending.");
 }catch(e){err.textContent=e.message}
}
async function forgotPassword(){
 const email=prompt("Enter your Somaiya/Gmail address:");
 if(!email)return;
 try{
   await api("/auth/request-password-reset-otp",{method:"POST",body:JSON.stringify({email})});
   const otp=prompt("Enter the 6-digit OTP sent to your email:");
   if(!otp)return;
   const password=prompt("Enter your new password (8+ characters):");
   if(!password)return;
   await api("/auth/reset-password",{method:"POST",body:JSON.stringify({email,otp,password})});
   toast("Password reset. You can sign in now.");
 }catch(e){toast(e.message)}
}
async function startGoogle(){try{const d=await api("/auth/google");location.href=d.url}catch(e){document.getElementById("loginError").textContent=e.message}}
function handleAuthCallback(){const m=location.hash.match(/^#auth-callback\?token=(.+)$/);if(!m)return false;try{token=decodeURIComponent(m[1]);localStorage.setItem(TOKEN_KEY,token);history.replaceState({},'', '#home');return true}catch{return false}}

document.addEventListener("click",async e=>{
 let x=e.target.closest("[data-open-report]");if(x){report(x.dataset.openReport);return}
 x=e.target.closest("[data-page-link]");if(x){navigate(x.dataset.pageLink);return}
 x=e.target.closest("[data-view-item]");if(x){detail(x.dataset.viewItem);return}
 x=e.target.closest("[data-claim-item]");if(x){claimOpen(x.dataset.claimItem);return}
 x=e.target.closest("[data-mark-returned]");if(x){returned(x.dataset.markReturned);return}
 x=e.target.closest("[data-approve-claim]");if(x){reviewClaim(x.dataset.approveClaim,"APPROVED");return}
 x=e.target.closest("[data-reject-claim]");if(x){reviewClaim(x.dataset.rejectClaim,"REJECTED");return}
 x=e.target.closest("[data-received-claim]");if(x){markReceivedClaim(x.dataset.receivedClaim);return}
 x=e.target.closest("[data-conversation]");if(x){openConversation(x.dataset.conversation);return}
 x=e.target.closest("[data-open-chat-user]");if(x){messageWithUser(x.dataset.openChatUser,x.dataset.chatItem);return}
 x=e.target.closest("[data-close-modal]");if(x){modal(x.closest(".modal-backdrop"),false);return}
 x=e.target.closest("[data-page]");if(x){e.preventDefault();navigate(x.dataset.page);return}
 x=e.target.closest(".filter");if(x){document.querySelectorAll("#homeFilters .filter").forEach(b=>b.classList.remove("active"));x.classList.add("active");homeFilter=x.dataset.filter;renderHome();return}
});

document.querySelectorAll("[data-auth-tab]").forEach(b=>b.addEventListener("click",()=>{const mode=b.dataset.authTab;document.querySelectorAll(".auth-tab").forEach(x=>x.classList.toggle("active",x===b));document.getElementById("loginPanel").classList.toggle("hidden-auth-panel",mode!=="login");document.getElementById("signupPanel").classList.toggle("hidden-auth-panel",mode!=="signup")}));
document.getElementById("googleLoginBtn")?.addEventListener("click",startGoogle);
document.getElementById("sendSignupOtpBtn")?.addEventListener("click",requestSignupOtp);
document.getElementById("signupForm")?.addEventListener("submit",signup);
document.getElementById("signupIdCard")?.addEventListener("change",previewSignupId);
document.getElementById("forgotPasswordBtn")?.addEventListener("click",forgotPassword);
document.getElementById("messageForm")?.addEventListener("submit",sendMessage);document.getElementById("saveContactPrefs")?.addEventListener("click",saveContactPrefs);
document.getElementById("reportForm").addEventListener("submit",submitReport);
document.getElementById("claimForm").addEventListener("submit",submitClaim);
document.getElementById("itemImage").addEventListener("change",upload);
document.getElementById("homeSearch").addEventListener("input",renderHome);
document.getElementById("homeSearchBtn").addEventListener("click",()=>{document.getElementById("searchPageInput").value=document.getElementById("homeSearch").value;navigate("search")});
document.getElementById("homeSearch").addEventListener("keydown",e=>{if(e.key==="Enter")document.getElementById("homeSearchBtn").click()});
document.getElementById("searchPageBtn").addEventListener("click",search);document.getElementById("searchPageInput").addEventListener("keydown",e=>{if(e.key==="Enter")search()});["searchStatus","searchCategory","searchLocation","searchSort"].forEach(id=>document.getElementById(id).addEventListener("change",search));
document.getElementById("logoutBtn").addEventListener("click",()=>logout());
document.getElementById("loginForm").addEventListener("submit",login);
document.getElementById("avatarBtn").addEventListener("click",()=>document.getElementById("avatarInput").click());
document.getElementById("avatarInput").addEventListener("change",uploadAvatar);
document.getElementById("idCardBtn").addEventListener("click",()=>document.getElementById("idCardInput").click());
document.getElementById("idCardInput").addEventListener("change",uploadId);
document.getElementById("profileForm").addEventListener("submit",saveProfile);
document.getElementById("claimHelpBtn")?.addEventListener("click",()=>toast("Moderator contact will be connected in the next block."));
document.getElementById("reportHelpBtn")?.addEventListener("click",()=>toast("Issue reporting will be connected in the next block."));
document.querySelectorAll(".modal-backdrop").forEach(b=>b.addEventListener("click",e=>{if(e.target===b)modal(b,false)}));
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.querySelectorAll(".modal-backdrop.open").forEach(m=>modal(m,false))});
window.addEventListener("popstate",()=>showPage(location.hash.slice(1)||"home"));window.addEventListener("hashchange",()=>showPage(location.hash.slice(1)||"home"));

(async function boot(){
 handleAuthCallback();
 if(!token){document.getElementById("authScreen").classList.remove("hidden");return}
 try{await refresh();document.getElementById("authScreen").classList.add("hidden");showPage(location.hash.slice(1)||"home")}catch(err){console.error(err);logout(false)}
})();
