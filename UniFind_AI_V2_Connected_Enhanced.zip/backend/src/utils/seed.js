import { pool } from '../db.js';
import { hashPassword } from './auth.js';

const passwordHash = await hashPassword('ChangeMe123!');

const users = [
  ['Demo Finder','DEMO001','demo@somaiya.edu'],
  ['Demo Claimant','TEST002','test2@somaiya.edu']
];

for (const [name,member_id,email] of users) {
  const result = await pool.query(
    `INSERT INTO users(name,member_id,email,password_hash,verification_status)
     VALUES($1,$2,$3,$4,'VERIFIED')
     ON CONFLICT(email) DO UPDATE SET
       password_hash=EXCLUDED.password_hash,
       verification_status='VERIFIED'
     RETURNING id,email`,
    [name,member_id,email,passwordHash]
  );
  console.log('Seed user:', result.rows[0]);
}

const finder = await pool.query(`SELECT id FROM users WHERE email='demo@somaiya.edu'`);
const ownerId = finder.rows[0].id;
const samples = [
  ['FOUND','Black Samsung S24','Black Samsung phone found near the library.','electronics','Bhaskaracharya Building B202'],
  ['FOUND','Blue water bottle','Blue insulated bottle found after class.','other','Aryabhatt Building A204'],
  ['LOST','Black wallet','Black leather wallet with cards, lost on campus.','accessories','Govinda Canteen']
];
for (const [type,title,description,category,location] of samples) {
  await pool.query(
    `INSERT INTO items(type,title,description,category,location,event_date,owner_id,status,storage_location)
     SELECT $1,$2,$3,$4,$5,CURRENT_DATE,$6,'ACTIVE',$7
     WHERE NOT EXISTS (SELECT 1 FROM items WHERE title=$2 AND owner_id=$6)`,
    [type,title,description,category,location,ownerId,type==='FOUND'?'Security / Finder desk':null]
  );
}
console.log('Demo password: ChangeMe123! — change/remove this before production.');
await pool.end();
