import express from 'express';
import { query } from '../db.js';
import { requireAuth } from '../middleware/auth.js';
import { createNotification } from '../services/notifications.js';

const router=express.Router();

async function participant(conversationId,userId){
  const r=await query(
    'SELECT 1 FROM conversation_participants WHERE conversation_id=$1 AND user_id=$2',
    [conversationId,userId]
  );
  return !!r.rows[0];
}

router.get('/conversations',requireAuth,async(req,res,next)=>{
  try{
    const r=await query(
      `SELECT c.id,c.item_id,c.created_at,c.updated_at,
              i.title AS item_title,
              COALESCE(json_agg(json_build_object('id',u.id,'name',u.name,'avatar',u.avatar_path))
              FILTER (WHERE u.id IS NOT NULL),'[]') AS participants,
              (SELECT content FROM messages m WHERE m.conversation_id=c.id ORDER BY m.created_at DESC LIMIT 1) AS last_message
       FROM conversations c
       JOIN conversation_participants me ON me.conversation_id=c.id AND me.user_id=$1
       LEFT JOIN items i ON i.id=c.item_id
       LEFT JOIN conversation_participants cp ON cp.conversation_id=c.id
       LEFT JOIN users u ON u.id=cp.user_id
       GROUP BY c.id,i.title
       ORDER BY c.updated_at DESC`,
      [req.user.id]
    );
    res.json({success:true,conversations:r.rows});
  }catch(err){next(err);}
});

router.post('/conversations',requireAuth,async(req,res,next)=>{
  try{
    const {otherUserId,itemId}=req.body;
    if(!otherUserId || otherUserId===req.user.id) return res.status(400).json({success:false,message:'A different user is required.'});

    const user=await query("SELECT id,name,allow_messages FROM users WHERE id=$1 AND status='ACTIVE'",[otherUserId]);
    if(!user.rows[0]) return res.status(404).json({success:false,message:'User not found.'});
    if(!user.rows[0].allow_messages) return res.status(403).json({success:false,message:'This user has disabled in-app messages.'});

    if(itemId){
      const item=await query('SELECT id,owner_id,status,type FROM items WHERE id=$1',[itemId]);
      if(!item.rows[0]) return res.status(404).json({success:false,message:'Item not found.'});
      const approved=await query(
        `SELECT 1 FROM claims WHERE item_id=$1 AND status='APPROVED'
         AND ((claimant_id=$2 AND EXISTS(SELECT 1 FROM items WHERE id=$1 AND owner_id=$3))
           OR (claimant_id=$3 AND EXISTS(SELECT 1 FROM items WHERE id=$1 AND owner_id=$2)))
         LIMIT 1`,
        [itemId,req.user.id,otherUserId]
      );
      if(!approved.rows[0]) return res.status(403).json({success:false,message:'Messaging for an item is unlocked only after its ownership claim is approved.'});
    }

    const existing=await query(
      `SELECT c.id FROM conversations c
       WHERE ($1::uuid IN (SELECT user_id FROM conversation_participants WHERE conversation_id=c.id))
         AND ($2::uuid IN (SELECT user_id FROM conversation_participants WHERE conversation_id=c.id))
         AND ($3::uuid IS NULL OR c.item_id=$3)
       LIMIT 1`,
      [req.user.id,otherUserId,itemId||null]
    );

    let conversationId=existing.rows[0]?.id;
    if(!conversationId){
      const c=await query('INSERT INTO conversations(item_id) VALUES($1) RETURNING id',[itemId||null]);
      conversationId=c.rows[0].id;
      await query(
        'INSERT INTO conversation_participants(conversation_id,user_id) VALUES($1,$2),($1,$3)',
        [conversationId,req.user.id,otherUserId]
      );
    }

    res.status(201).json({success:true,conversationId});
  }catch(err){next(err);}
});

router.get('/conversations/:id/messages',requireAuth,async(req,res,next)=>{
  try{
    if(!await participant(req.params.id,req.user.id)) return res.status(403).json({success:false,message:'Conversation access denied.'});
    const r=await query(
      `SELECT m.*,u.name AS sender_name,u.avatar_path AS sender_avatar
       FROM messages m JOIN users u ON u.id=m.sender_id
       WHERE m.conversation_id=$1 ORDER BY m.created_at ASC`,
      [req.params.id]
    );
    await query(
      `UPDATE messages SET read_at=NOW()
       WHERE conversation_id=$1 AND sender_id<>$2 AND read_at IS NULL`,
      [req.params.id,req.user.id]
    );
    res.json({success:true,messages:r.rows});
  }catch(err){next(err);}
});

router.post('/conversations/:id/messages',requireAuth,async(req,res,next)=>{
  try{
    if(!await participant(req.params.id,req.user.id)) return res.status(403).json({success:false,message:'Conversation access denied.'});
    const content=String(req.body.content||'').trim();
    if(!content) return res.status(400).json({success:false,message:'Message cannot be empty.'});
    if(content.length>4000) return res.status(400).json({success:false,message:'Message is too long.'});

    const result=await query(
      `INSERT INTO messages(conversation_id,sender_id,content) VALUES($1,$2,$3) RETURNING *`,
      [req.params.id,req.user.id,content]
    );
    await query('UPDATE conversations SET updated_at=NOW() WHERE id=$1',[req.params.id]);

    const others=await query(
      `SELECT user_id FROM conversation_participants WHERE conversation_id=$1 AND user_id<>$2`,
      [req.params.id,req.user.id]
    );
    for(const row of others.rows){
      await createNotification({
        userId:row.user_id,type:'MESSAGE',title:'New message',
        message:`You have a new UniFind message from ${req.user.name}.`
      });
    }

    res.status(201).json({success:true,message:result.rows[0]});
  }catch(err){next(err);}
});

export default router;
