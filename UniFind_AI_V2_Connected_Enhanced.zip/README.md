# UniFind AI V2 — Connected Campus Lost & Found

This package keeps the existing Express + PostgreSQL architecture and upgrades the V2 user flow without replacing the matching engine.

## Run

1. Open `backend/`.
2. Copy `.env.example` to `.env` and configure PostgreSQL/JWT.
3. Run:
```bash
npm install
npm run db:init
npm run db:seed
npm run dev
```
4. Serve the project root with Live Server, or any static file server, and open `index.html`.

The frontend automatically uses `/api` when served from port 5000, otherwise it falls back to `http://localhost:5000/api`. You can override this with `window.UNIFIND_API`.

## Demo accounts

- Finder: `demo@somaiya.edu` / `ChangeMe123!`
- Claimant: `test2@somaiya.edu` / `ChangeMe123!`

Both demo users are seeded as verified so the complete claim flow can be tested immediately.

## Updated flow

- Sign in with password or Google OAuth when Google keys are configured.
- New users sign up with Somaiya email or Gmail, create a password, receive an OTP, and upload their Somaiya ID card.
- ID-card OCR is attempted automatically. The OCR text is stored privately and a strong name + member-ID match can mark the account verified.
- Unverified users cannot submit ownership claims.
- Found-item owners review claims and approve/reject them.
- Approval changes the found item to `CLAIMED`, rejects competing pending claims, and creates a private conversation for the finder and approved claimant.
- The claimant confirms **I received it**. Only the approved claimant can perform this action; then the item becomes `RETURNED`.
- Item photos are served through the configured API origin rather than a hard-coded localhost URL.
- Profile contact preferences control in-app messaging/call/email availability.
- Campus locations include Aryabhatt (A101–A418), Bhaskaracharya (B101–B618), the named canteens, libraries, hostels and major campus facilities.

## Google OAuth

Configure:
- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `GOOGLE_REDIRECT_URI`

The callback returns to the frontend using the JWT hash callback already supported by the V2 client.

## Important

ID cards and their OCR text are private. Only authenticated profile/admin flows can access them. Never commit `.env` or real credentials.
